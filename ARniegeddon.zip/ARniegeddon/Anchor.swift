//
//  Anchor.swift
//  ARniegeddon
//
//  Created by Willian Honda on 20/03/18.
//  Copyright © 2018 Ray Wenderlich. All rights reserved.
//

import ARKit

class Anchor: ARAnchor {
  var type: NodeType?
}
