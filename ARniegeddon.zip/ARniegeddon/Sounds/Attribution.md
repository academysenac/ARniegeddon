
lose.wav from Mativve
https://freesound.org/s/391536/

win.wav from Mativve
https://freesound.org/s/391539/

